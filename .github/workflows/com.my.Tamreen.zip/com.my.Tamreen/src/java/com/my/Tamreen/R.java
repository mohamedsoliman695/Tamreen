/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  java.lang.Object
 */
package com.my.Tamreen;

public final class R {

    public static final class attr {
    }

    public static final class color {
        public static int colorAccent = 2130968578;
        public static int colorControlHighlight = 2130968579;
        public static int colorControlNormal = 2130968580;
        public static int colorPrimary = 2130968576;
        public static int colorPrimaryDark = 2130968577;
    }

    public static final class drawable {
        public static int app_icon = 2130837504;
        public static int default_image = 2130837505;
    }

    public static final class id {
        public static int a1 = 2131165199;
        public static int a2 = 2131165206;
        public static int a3 = 2131165213;
        public static int a4 = 2131165220;
        public static int a5 = 2131165227;
        public static int c1 = 2131165198;
        public static int c2 = 2131165205;
        public static int c3 = 2131165212;
        public static int c4 = 2131165219;
        public static int c5 = 2131165226;
        public static int home = 2131165186;
        public static int hscroll1 = 2131165184;
        public static int k1 = 2131165200;
        public static int k2 = 2131165207;
        public static int k3 = 2131165214;
        public static int k4 = 2131165221;
        public static int k5 = 2131165228;
        public static int linear1 = 2131165185;
        public static int linear10 = 2131165194;
        public static int linear14 = 2131165201;
        public static int linear15 = 2131165208;
        public static int linear16 = 2131165215;
        public static int linear17 = 2131165222;
        public static int linear18 = 2131165229;
        public static int linear19 = 2131165230;
        public static int sum = 2131165231;
        public static int t1 = 2131165196;
        public static int t2 = 2131165203;
        public static int t3 = 2131165210;
        public static int t4 = 2131165217;
        public static int t5 = 2131165224;
        public static int textview1 = 2131165188;
        public static int textview4 = 2131165189;
        public static int textview45 = 2131165195;
        public static int textview47 = 2131165197;
        public static int textview5 = 2131165190;
        public static int textview6 = 2131165192;
        public static int textview69 = 2131165202;
        public static int textview7 = 2131165193;
        public static int textview71 = 2131165204;
        public static int textview75 = 2131165209;
        public static int textview77 = 2131165211;
        public static int textview8 = 2131165191;
        public static int textview81 = 2131165216;
        public static int textview83 = 2131165218;
        public static int textview87 = 2131165223;
        public static int textview89 = 2131165225;
        public static int tr = 2131165187;
    }

    public static final class layout {
        public static int main = 2130903040;
    }

    public static final class string {
        public static int app_name = 2131034112;
    }

    public static final class style {
        public static int AppTheme = 2131099648;
        public static int FullScreen = 2131099649;
        public static int NoActionBar = 2131099650;
        public static int NoStatusBar = 2131099651;
    }

}

