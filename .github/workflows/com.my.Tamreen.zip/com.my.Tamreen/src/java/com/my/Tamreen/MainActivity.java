/*
 * Decompiled with CFR 0.0.
 * 
 * Could not load the following classes:
 *  android.app.Activity
 *  android.content.Context
 *  android.content.Intent
 *  android.content.res.Resources
 *  android.os.Bundle
 *  android.util.DisplayMetrics
 *  android.util.SparseBooleanArray
 *  android.util.TypedValue
 *  android.view.View
 *  android.view.View$OnClickListener
 *  android.widget.HorizontalScrollView
 *  android.widget.LinearLayout
 *  android.widget.ListView
 *  android.widget.TextView
 *  android.widget.Toast
 *  java.lang.CharSequence
 *  java.lang.Deprecated
 *  java.lang.Double
 *  java.lang.Object
 *  java.lang.String
 *  java.util.ArrayList
 *  java.util.Random
 */
package com.my.Tamreen;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.my.Tamreen.R;
import java.util.ArrayList;
import java.util.Random;

public class MainActivity
extends Activity {
    private TextView a1;
    private TextView a2;
    private TextView a3;
    private TextView a4;
    private TextView a5;
    private TextView c1;
    private TextView c2;
    private TextView c3;
    private TextView c4;
    private TextView c5;
    private LinearLayout home;
    private HorizontalScrollView hscroll1;
    private TextView k1;
    private TextView k2;
    private TextView k3;
    private TextView k4;
    private TextView k5;
    private LinearLayout linear1;
    private LinearLayout linear10;
    private LinearLayout linear14;
    private LinearLayout linear15;
    private LinearLayout linear16;
    private LinearLayout linear17;
    private LinearLayout linear18;
    private LinearLayout linear19;
    private TextView sum;
    private TextView t1;
    private TextView t2;
    private TextView t3;
    private TextView t4;
    private TextView t5;
    private TextView textview1;
    private TextView textview4;
    private TextView textview45;
    private TextView textview47;
    private TextView textview5;
    private TextView textview6;
    private TextView textview69;
    private TextView textview7;
    private TextView textview71;
    private TextView textview75;
    private TextView textview77;
    private TextView textview8;
    private TextView textview81;
    private TextView textview83;
    private TextView textview87;
    private TextView textview89;
    private LinearLayout tr;

    private void initialize(Bundle bundle) {
        this.hscroll1 = (HorizontalScrollView)this.findViewById(R.id.hscroll1);
        this.linear1 = (LinearLayout)this.findViewById(R.id.linear1);
        this.home = (LinearLayout)this.findViewById(R.id.home);
        this.linear18 = (LinearLayout)this.findViewById(R.id.linear18);
        this.tr = (LinearLayout)this.findViewById(R.id.tr);
        this.linear10 = (LinearLayout)this.findViewById(R.id.linear10);
        this.linear14 = (LinearLayout)this.findViewById(R.id.linear14);
        this.linear15 = (LinearLayout)this.findViewById(R.id.linear15);
        this.linear16 = (LinearLayout)this.findViewById(R.id.linear16);
        this.linear17 = (LinearLayout)this.findViewById(R.id.linear17);
        this.textview1 = (TextView)this.findViewById(R.id.textview1);
        this.textview4 = (TextView)this.findViewById(R.id.textview4);
        this.textview5 = (TextView)this.findViewById(R.id.textview5);
        this.textview8 = (TextView)this.findViewById(R.id.textview8);
        this.textview6 = (TextView)this.findViewById(R.id.textview6);
        this.textview7 = (TextView)this.findViewById(R.id.textview7);
        this.textview45 = (TextView)this.findViewById(R.id.textview45);
        this.t1 = (TextView)this.findViewById(R.id.t1);
        this.textview47 = (TextView)this.findViewById(R.id.textview47);
        this.c1 = (TextView)this.findViewById(R.id.c1);
        this.a1 = (TextView)this.findViewById(R.id.a1);
        this.k1 = (TextView)this.findViewById(R.id.k1);
        this.textview69 = (TextView)this.findViewById(R.id.textview69);
        this.t2 = (TextView)this.findViewById(R.id.t2);
        this.textview71 = (TextView)this.findViewById(R.id.textview71);
        this.c2 = (TextView)this.findViewById(R.id.c2);
        this.a2 = (TextView)this.findViewById(R.id.a2);
        this.k2 = (TextView)this.findViewById(R.id.k2);
        this.textview75 = (TextView)this.findViewById(R.id.textview75);
        this.t3 = (TextView)this.findViewById(R.id.t3);
        this.textview77 = (TextView)this.findViewById(R.id.textview77);
        this.c3 = (TextView)this.findViewById(R.id.c3);
        this.a3 = (TextView)this.findViewById(R.id.a3);
        this.k3 = (TextView)this.findViewById(R.id.k3);
        this.textview81 = (TextView)this.findViewById(R.id.textview81);
        this.t4 = (TextView)this.findViewById(R.id.t4);
        this.textview83 = (TextView)this.findViewById(R.id.textview83);
        this.c4 = (TextView)this.findViewById(R.id.c4);
        this.a4 = (TextView)this.findViewById(R.id.a4);
        this.k4 = (TextView)this.findViewById(R.id.k4);
        this.textview87 = (TextView)this.findViewById(R.id.textview87);
        this.t5 = (TextView)this.findViewById(R.id.t5);
        this.textview89 = (TextView)this.findViewById(R.id.textview89);
        this.c5 = (TextView)this.findViewById(R.id.c5);
        this.a5 = (TextView)this.findViewById(R.id.a5);
        this.k5 = (TextView)this.findViewById(R.id.k5);
        this.linear19 = (LinearLayout)this.findViewById(R.id.linear19);
        this.sum = (TextView)this.findViewById(R.id.sum);
        this.a1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.a1.setText((CharSequence)"73%");
            }
        });
        this.k1.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.k1.setText((CharSequence)"73");
            }
        });
        this.a2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.a2.setText((CharSequence)"0%");
            }
        });
        this.k2.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.k2.setText((CharSequence)"0");
            }
        });
        this.a3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.a3.setText((CharSequence)"0.38%");
            }
        });
        this.k3.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.k3.setText((CharSequence)"0.38");
            }
        });
        this.a4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.a4.setText((CharSequence)"0.26");
            }
        });
        this.k4.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.k4.setText((CharSequence)"0.26");
            }
        });
        this.a5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.a5.setText((CharSequence)"0%");
            }
        });
        this.k5.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.k5.setText((CharSequence)"0");
            }
        });
        this.sum.setOnClickListener(new View.OnClickListener(){

            public void onClick(View view) {
                MainActivity.this.sum.setText((CharSequence)"15500065.18");
            }
        });
    }

    private void initializeLogic() {
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList arrayList = new ArrayList();
        SparseBooleanArray sparseBooleanArray = listView.getCheckedItemPositions();
        int n = 0;
        while (n < sparseBooleanArray.size()) {
            if (sparseBooleanArray.valueAt(n)) {
                arrayList.add((Object)sparseBooleanArray.keyAt(n));
            }
            ++n;
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int n) {
        return TypedValue.applyDimension((int)1, (float)n, (DisplayMetrics)this.getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return this.getResources().getDisplayMetrics().heightPixels;
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return this.getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] arrn = new int[2];
        view.getLocationInWindow(arrn);
        return arrn[1];
    }

    @Deprecated
    public int getRandom(int n, int n2) {
        return n + new Random().nextInt(1 + (n2 - n));
    }

    protected void onActivityResult(int n, int n2, Intent intent) {
        super.onActivityResult(n, n2, intent);
    }

    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        this.setContentView(R.layout.main);
        MainActivity.super.initialize(bundle);
        MainActivity.super.initializeLogic();
    }

    @Deprecated
    public void showMessage(String string2) {
        Toast.makeText((Context)this.getApplicationContext(), (CharSequence)string2, (int)0).show();
    }

}

